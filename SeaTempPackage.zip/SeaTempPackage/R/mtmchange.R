utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Month-to-Month Temperature Change
#'
#' @param df dataframe with columns Year, Month, Depth, Temp
#'
#' @return dataframe with MonthToMonth column
#' @export
mtm_change <- function(df) {
  df %>%
    arrange(Depth, Year, Month) %>%
    group_by(Year, Depth) %>%
    mutate(MonthToMonth = lead(Temp) - Temp) %>%
    ungroup()
}
