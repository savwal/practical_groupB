utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Plot month-to-month temperature change for a specific year
#'
#' @param df dataframe processed by mtm_change
#' @param year_select numeric, year to plot
#'
#' @return ggplot object
#' @export
plot_mtm <- function(df, year_select) {
  df_year <- df %>% filter(Year == year_select) %>%
    tidyr::complete(Month = 1:12, Depth, fill = list(MonthToMonth = NA))

  ggplot(df_year, aes(x = Month, y = MonthToMonth, color = factor(Depth))) +
    geom_line(size = 1) +
    geom_point(size = 2) +
    scale_x_continuous(breaks = 1:12) +
    labs(
      title = paste("Month-to-Month Temperature Change —", year_select),
      x = "Month",
      y = "Δ Temperature (°C)",
      color = "Depth (m)"
    ) +
    theme_minimal()
}
