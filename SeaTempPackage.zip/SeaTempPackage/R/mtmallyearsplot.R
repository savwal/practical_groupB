utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Average month-to-month temperature change across all years
#'
#' @param df dataframe processed by mtm_change
#' @param depths numeric vector of depths to include
#'
#' @return ggplot object
#' @export
plot_mtm_average <- function(df, depths = NULL) {
  if (!is.null(depths)) df <- df %>% filter(Depth %in% depths)
  avg_mtm <- df %>%
    group_by(Depth, Month) %>%
    summarise(Avg_MonthToMonth = mean(MonthToMonth, na.rm = TRUE), .groups = "drop")

  ggplot(avg_mtm, aes(x = Month, y = Avg_MonthToMonth, color = factor(Depth))) +
    geom_line(size = 1) +
    geom_point(size = 2) +
    scale_x_continuous(breaks = 1:12) +
    labs(
      title = "Average Month-to-Month Temperature Change Across All Years",
      x = "Month",
      y = "Δ Temperature (°C)",
      color = "Depth (m)"
    ) +
    theme_minimal()
}
