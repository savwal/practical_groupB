utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Calculate anomaly from PairedYears column
#'
#' @param df dataframe with Temp and PairedYears
#'
#' @return dataframe with Anomaly column
#' @export
calc_anomaly_from_column <- function(df) {
  df %>%
    mutate(Anomaly = Temp - PairedYears)
}
