utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Simulate dataset
#'
#' @param years number of years
#' @param depths numeric vector of depths
#'
#' @return dataframe
#' @export
simulate_dataset <- function(years = 5, depths = c(0, -20, -50, -80)) {
  library(truncnorm)
  expand.grid(
    Year = 1996:(1996 + years - 1),
    Month = 1:12,
    Depth = depths
  ) %>%
    mutate(
      Temp = round(rtruncnorm(n(), a = 10, b = 22, mean = 16, sd = 2), 2),
      PairedYears = round(rtruncnorm(n(), a = 10, b = 22, mean = 15.5, sd = 1.8), 2)
    )
}
