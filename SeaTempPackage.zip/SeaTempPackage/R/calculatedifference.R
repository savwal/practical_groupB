utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))


#' Calculate difference from previous 30 years
#'
#' @param df dataframe with Temp and PairedYears columns
#' @param years numeric vector of years to include
#' @param depths numeric vector of depths to include
#'
#' @return dataframe with Diff30yr column
#' @export
calc_diff_30yr <- function(df, years = NULL, depths = NULL) {
  if (!is.null(years)) df <- df[df$Year %in% years, ]
  if (!is.null(depths)) df <- df[df$Depth %in% depths, ]

  df$Temp <- as.numeric(gsub(",", ".", df$Temp))
  df$PairedYears <- as.numeric(gsub(",", ".", df$PairedYears))

  df$Diff30yr <- df$Temp - df$PairedYears
  return(df)
}
