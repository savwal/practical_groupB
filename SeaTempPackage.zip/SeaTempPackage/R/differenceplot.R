utils::globalVariables(c(
  "MonthToMonth", "Month", "Depth", "Year", "Temp",
  "PairedYears", "Diff30yr", "Anomaly"
))

#' Plot difference from previous 30 years
#'
#' @param df dataframe processed by calc_diff_30yr
#'
#' @return prints per-year and average plots
#' @export
plot_diff_30yr <- function(df) {
  per_year_plot <- ggplot(df, aes(x = Month, y = Diff30yr, color = factor(Depth), group = Depth)) +
    geom_line(size = 1) +
    geom_point(size = 2) +
    facet_wrap(~Year, scales = "free_y") +
    scale_x_continuous(breaks = 1:12) +
    labs(
      title = "Monthly Temperature Difference from 30-Year Average (per year)",
      x = "Month",
      y = "Difference (°C)",
      color = "Depth (m)"
    ) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  print(per_year_plot)

  avg_diff <- aggregate(Diff30yr ~ Month + Depth, df, mean)
  avg_plot <- ggplot(avg_diff, aes(x = Month, y = Diff30yr, color = factor(Depth), group = Depth)) +
    geom_line(size = 1) +
    geom_point(size = 2) +
    scale_x_continuous(breaks = 1:12) +
    labs(
      title = "Average Monthly Temperature Difference from 30-Year Average",
      x = "Month",
      y = "Difference (°C)",
      color = "Depth (m)"
    ) +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))
  print(avg_plot)
}
